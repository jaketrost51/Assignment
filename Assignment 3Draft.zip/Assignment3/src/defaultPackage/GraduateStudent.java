package defaultPackage;

import java.util.ArrayList;

//SubClass Graduate Student Class that Extends the Student SuperClass
public class GraduateStudent extends Student{
	
	//Additional Attributes for Subclass
	public  String advisorName;
	public  String thesisTitle;
	
	
	//Subclass constructor for Graduate Student
	public GraduateStudent(String sID, String myName, int myAge,  String myMajor, ArrayList<Double> myGrades, String aName, String tTitle) {
			super(sID, myName, myAge, myMajor, myGrades);
			advisorName = aName;
			thesisTitle = tTitle;	
}
	
		
	
	//****Getters****
	public String getAdvisorName() {
		return advisorName;		
	}
	
	public String getThesisTitle() {
		return thesisTitle;
	}
	
	
		
	
	//****Setters****
	public void setAdvisorName(String adName) {
		advisorName = adName;		
	}
		
	public void setThesisTitle(String thesis) {
		thesisTitle = thesis;
	}
	
	
	
	
	
	
	@Override   //Overrides the SuperClass toString Method
	
	public  String toString() {
		String displayGradStudent = "GRADUATE STUDENT:\n " + "Student ID: " + studentID + "    Student Name: " 
				 + name + "    Major: " + major + "    Age: "  + age + "    Grade: "
				 + grades + "    Advisor Name: " + advisorName + "    Thesis Title: " 
				 + thesisTitle;
					return displayGradStudent;
}
}