package defaultPackage;
import java.util.ArrayList;


//SubClass Undergrad that Extends Student SuperClass
public class UnderGraduate extends Student {
	//Additional Attributes for SubClass
	private  int yearsOfStudy;
	private  String minor = "";
	
	//Constructor for the Undergraduate SubClass
	public UnderGraduate(String sID, String myName,int myAge, String myMajor, ArrayList<Double> myGrades, int yrsOfStudy, String m ) {
		super(sID,myName, myAge, myMajor, myGrades);
		yearsOfStudy = yrsOfStudy;
		minor = m;				
	}
	
			
	
	//****Getters****
	public int getYearsOfStudy() {
		return yearsOfStudy;		
	}
	
	public String getMinor() {
		return minor;
	}	
	
	
	
		//****Mutators****		
	public void  setYearsOfStudy(int yrs) {
		yearsOfStudy = yrs;		
	}
		
	public void setMinor(String Minor) {
		minor = Minor;
		
	}
	
	
	
	
	
	
	
	@Override  //Overrides the SuperClass toString
	
	//ToString Method to Display Contents
	public  String toString() {
		String displayUnderGrad = "UNDERGRADUATE STUDENT:\n " + "Student ID: " + studentID + "    Student Name: " 
				 + name + "    Major: " + major + "    Age: "  + age + "    Grade: "
				 + grades + "    Minor: " + minor + "    College Year: " + yearsOfStudy;
				 	return displayUnderGrad;
	}
}
