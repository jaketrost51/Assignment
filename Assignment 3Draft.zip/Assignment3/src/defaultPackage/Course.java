package defaultPackage;




public class Course {
	
	//Course Class Attributes
	private String courseID;
	private String courseName;
	private String instructorName;
	private int credits;
	
	
	
	//Course Class Constructor
	
	public Course(String cID, String courseN, String instructor, int myCredits) {
		
		courseID = cID;
		courseName = courseN;
		instructorName = instructor;
		credits = myCredits; 
		
		
	}
	
	
	//****Getters****
	
	public String getCourseID() {		
		return courseID;
	}
	
	public String getCourse() {		
		return courseName;
	}
	
	public String getInstructor() {	
		return instructorName;
	}
	
	public int getCredits() {	
		return credits;
	}
	
	
	
	
	//****Setters****
	
	public void setCourseID(String cID) {		
		courseID = cID;
	}
	
	public void setCourse(String course) {		
		courseName = course;
	}
	
	public void setInstructor(String instructor) {	
		instructorName = instructor;
	}
	
	public void setCredits(int myCredits) {	
		credits = myCredits;
	}
}
	
	
	 

	
	
	
