package defaultPackage;
import java.io.*;
import java.util.*;

//Student Super Class
public class Student implements Serializable {
	
	//Student Class Attributes
	public String studentID;
	public String name;
	public String major;
	public int age;
	public ArrayList<Double> grades; 		 //To Hold list of Grades
	public ArrayList<Course> listOfCourses;  //To Hold Courses Assigned
	
	//Constructor for student class
	
	public Student(String sID, String myName, int myAge, String myMajor, ArrayList<Double> myGrades) {
						
			studentID = sID;
			name = myName; 
			major = myMajor;
			age = myAge;
			
			//NEEDS WORK FOR CHAR INPUT
			for (Double grade : myGrades) {
				if (grade <1 || grade >100) {
					throw new IllegalArgumentException("Please enter a grade between 1-100");
			}
			grades = myGrades;
			listOfCourses = new ArrayList<>();
			
			}	
	}  
	
	
	
	
	
	//Getters
	
	public String getStudentId() {		
		return studentID;
	}

    public String getStudentName() {	
    	return name;
}

    public String getMajor() {	
    	return major;
}

    public int getAge() {	
    	return age;
}
    
    
    public String getGrades() {    	
    	return grades.toString();
    }
    
    
    
    
    
    
    //Setters
    
public void setStudentID(String sID) {   	
    	studentID = sID;
    }
public void setName(String sName) {	
	name = sName;
}
public void setMajor(String myMajor) {	
	major = myMajor;
}
public void setAge(int myAge) {	
	age = myAge;
}
public void setGrades(ArrayList<Double> myGrades) {	
	grades = myGrades;
}
    







//Sum Grades Method to start the recursion -- Will only be used inside of another method
public double sumGrades(int i) { 
	
	//This is Considered the base case because once the statement reaches the end of the array,  it stops it from infinitely looping on itself
	if (i == grades.size()) {     
		return 0;  
	}
	//This is the Recursive case because it reuses the method on itself to loop until it reaches the end. 
	double summation = grades.get(i) + sumGrades(i+1);
	return summation;	//Returning the sum will be used for the Calculate GPA method	
				
}


//Taking the SumGrades to Calculate the GPA by finding average of the grades

public double calculateGPARecursively() {
	double addGPA = sumGrades(0);  //This is used to indicate the sumGrades method starting at the first index, '0' , in the grades ArrayList
	double averageGPA = addGPA/grades.size(); //Since each grades Array size will be different,  we divide the sum by the size of each array to find average
	return averageGPA;
}














//Custom Student Method to Assign Course to the Course Array attached to each student object
 public void assignStudentCourses(Course sCourse) {
	 listOfCourses.add(sCourse);
	 
 }
    
 
 
 
 //@Override
 
	 
	 //To String Method to help display contents
	 public String toString() {
		    return "Student ID: " + studentID + ", Name: " + name + ", Age: " + age + ", Major: " + major + ", Grades: " + grades.toString();
	 
 }
 
 
 
 
 
 
 








}
    
    
    
    
    
    
	
	
	