package defaultPackage;

import java.io.*;
import java.util.*;
import java.util.ArrayList;

import java.util.Scanner;



public class AssignmentOneFinal {
	
	//Create an Array List to Hold any number of Student Objects
	public static ArrayList<Student> students = new ArrayList<>(0);
	
	//Create an Array List to Hold any number of Course Objects
	private static ArrayList<Course> courses = new ArrayList<>(0);


	

	//Main Method
	public static void main(String[] args) throws Exception {
	
				//create a scanner object
				Scanner keyboard = new Scanner(System.in);
											
		        //Create a variable to flag the while loop
		        boolean loop = true;
		        
		        //While Loop for Initial Menu
		        while (loop) {

		            System.out.println("\n1. Add Student");

		            System.out.println("2. Add Course");
		            		           
		            System.out.println("3. Assign Course ");

		            //System.out.println("4. Assign Grade");
		            
		            System.out.println("4. List of Students");
		            
		            System.out.println("5. Save Data");
		            
		            System.out.println("6. Load Data");

		            System.out.println("7. Exit");

		            System.out.println("\nChoose an option: ");

		            	int choice = keyboard.nextInt();

		
		           //Switch Case to implement Methods Depending on User Choice 	
		            switch (choice) {

		                case 1:
		                   addStudent();		                	                   
		                    break;
		            

		                case 2: 
		                   addCourse();		                   
		                   	break;
		                
		                   	
		                case 3:		                	
		                	assignCourse();		                		                	
		                	break;
		                	
		                	
		                /*case 4: 		                	
		                	assignStudentGrade();
		                	break; 
		                */	
		                case 4:		                	
		                	for (Student student : students) {
		                	    System.out.println(student.toString());
		                	    System.out.println();
		                	}
		                    break;
		                    
		                    
		                case 5: 	                	
		                	createFile();		                	
		                	break;
		                	
		                	
		                case 6: 		                	
		                	loadStudentsFromFile("C:\\Users\\jaket\\OneDrive\\Desktop\\students_data.txt");		                	
		                	break;
		                
		                case 7: 
		                	System.out.println("Goodbye");
		                	loop = false;
		                	
		                	break; 
		                	
		                default:
		            }
		                	
		        }
		                		                			            		        
		    }
	
	
	
	
		            //**********Method to Create a Student Object*************
		            private static void addStudent() throws DuplicateIDException{   //To Ensure no duplicate student created
		            	
		            	//Create a local Scanner Object
		            	Scanner keyboard = new Scanner(System.in);
		            	
		            	//Ask user to choose to Create a new Graduate Student or Undergraduate Student
		            	System.out.println("Would you like to input a 1: Graduate Student "
		            			+ "or 2:  Undergraduate Student." + "\n *** Press 1 or 2 ***");
		            	
		            		int graduate = keyboard.nextInt();
		            	
		            	//If Else Statemennt to determine which Method to use based on user choice. 	
		            	if (graduate == 1) {           		
		            		assignGraduateStudent(); 
		            		
		            	}else if (graduate == 2) {		            		
		            		assignUndergrad();
		            	}
		            }

		            	
		            	
		            	
		           
		               
						
						
		            
		            
		            //******Method to Create a course object********
		            private static void addCourse() {
		            	
		            	//Create a local Scanner Object
		            	Scanner keyboard = new Scanner(System.in);
		            	
		            	
		            	//Get Course ID
		            	 System.out.print("\nEnter Course ID: ");
			                String courseID = keyboard.nextLine();
			                
			                
			            //Get Course Name   
			             System.out.print("\nEnter Course Name: ");
			                String courseName = keyboard.nextLine();
			                
			               
			            //Get Instructor Name    
			             System.out.print("\nEnter Instructor Name: ");
			                String  instructorName = keyboard.nextLine();
			                
			                
			            //Get Credit Hours    
			             System.out.print("\nEnter Class Credit Hours: ");
			                int  credits = keyboard.nextInt();
		            
			            //Create a new Course object with the use inputs    			                
			                Course course = new Course(courseID, courseName, instructorName, credits);
			                	courses.add(course);  //Add newly created object to courses array
			                		System.out.println("\nCourse Added.");  //Success message
		            }

		     
		            	
		      
		            			
		            			// ********ASSIGN COURSE METHOD**********

				            public static void assignCourse() {
				            	//Create a local Scanner object
				            	Scanner keyboard = new Scanner(System.in);
				            	
				            	//Collect Student Name for searching
				            	System.out.println("\nWhat is the name of the student you would like to assign a course to?");
				            		String sName = keyboard.nextLine(); //Store in variable to use in locatestudent method
				            	
				            	//Collect Course Input for assigning
				            	System.out.println("\nWhat course would you like to assign to " + sName);
				            		String cName = keyboard.nextLine(); // Store in variable to use in locateCourse method
				            	
				            	//Create local student object to scan through locate student method
				                Student student = locateStudent(sName);
				                
				                //Create local Course object to scan through locate course method
				                Course course = locateCourse(cName);		
				                
				                //Assigning a grade to the student Course Assigned
				             	//assignStudentGrade();	//Needs work	               

				             	//If Statement to ensure inputs are valid
				                if (student != null && course != null) {
				                    student.assignStudentCourses(course); //Custom Student class method used to assign course
				                    	System.out.println("\n" + cName + " assigned to " + sName + "with grade assigned " );

				                } else {

				                    System.out.println("\nInvalid Entry.");
				                    				                    
				                }

				            }
				        				            
				        
				            
				            
				            
				            //***********Method to Locate Student By Student ID***********
				            public static Student locateSID(String sID) {
				            	
				            	//For Loop that scans the array of Students for the matching Student ID
				            	for (Student student : students) {
				            		if (student.getStudentId().equals(sID)) {  //When scanning,  if statement to match Student ID
				            			return student;
				            		}
				            	}
								return null;
				            }

				            
				            
				            
				            //***********Method to Locate Student by by Student Name**********

				            public static Student locateStudent(String sName) {

				            	//For Loop that scans the array of Students for the matching Student name
				                for (Student student : students) {
				                    if (student.getStudentName().equals(sName)) { //When scanning,  if statement to match Student name
				                        return student;				        
				                    }
				                }				            
				                	return null;				             
				            }

				            				       				            

				            //********Method to locate course by matching*************

				               private static Course locateCourse(String cName) {		        	   	            
				             
				            	 //For Loop that scans the array of courses for the matching course name
				            	   for (Course course : courses) {           
				            		   if(course.getCourse().equals(cName)) { //When scanning,  if statement to match course name
				            			   return course; 
				        		   }
				        	   }				        	  
				            	   return null;
		            
		            
		            
}
				            //*******Assign student object a grade Method*******
				               
				            //Method Not Needed Right now.
				               
				           /* public static void assignStudentGrade() {
				            	   
				            	  //Create a local Scanner Object
				            	  Scanner keyboard = new Scanner(System.in);
				            	  
				            	  //Create an array for student grades
				            	  ArrayList<Double> grade = new ArrayList<>();
				            	   
				            	  //Prompt User Input
				            	  System.out.println("\nWhat grade would you like to enter for the course?:  ");				            	   
				            	  	double inputGrade = keyboard.nextDouble();
				            	  
				            	  //Assign user input to a variable then assign to the new Array for Grades
				            	  grade.add(inputGrade);	
				            	  
				            	  //Set the student grade array using setter toward specified object
				            	  Student.setGrades(grade); //Need some work.
				            		   
				            	   }
				            	   */
				            	   
				               
				               
				            //*******GRADUATE STUDENT METHOD*********	 
				               
				            public static void assignGraduateStudent() {
				            	
				            	//Local Scanner Object to collect input
				                Scanner keyboard = new Scanner(System.in);
				            	
				                //Get Graduate Student ID
				            	System.out.print("\nEnter student ID in the form of ABC123: ");				            			               				               
				                	String sID = keyboard.nextLine();
				                				              				              				                				                				                				          				          				                
				                
				                
				                //Get Graduate Student Name
				                System.out.print("\nEnter student name: ");
				                	String myName = keyboard.nextLine();
				                
				                
				                
				                //Get Graduate Student Major
				                System.out.print("\nEnter student major: ");
				                	String  myMajor = keyboard.nextLine();
				                
				                
				                
				                //Get Graduate Student age
				                System.out.print("\nEnter student age: ");
				                	int  myAge = keyboard.nextInt();
				                 				          
				              
				                
				                //Get Graduate Student Grade
				                System.out.print("\nEnter Student Grade: ");
				                	ArrayList<Double> myGrades = new ArrayList<>();
				                		double grades = keyboard.nextDouble();
				                			myGrades.add(grades);
				                				keyboard.nextLine();
				                
				                
				                //Get Graduate Student Advisor Name
				                
				                System.out.println("\nEnter Grad Student Advisor Name: ");
				                	String advisorName = keyboard.nextLine();
				                
				               
				                
				                //Get Graduate Student Thesis Title
				                System.out.println("\nEnter Student Thesis Title: ");
				                	String thesisTitle = keyboard.nextLine();
				                	System.out.println();
				                
				                
				                
				                //Try Catch Block for Duplicate ID
				                try {
					                for (Student student : students) {  //For loop to loop through the array to find duplicate
					                	if (student.getStudentId().equals(sID)) {
						                	throw new DuplicateIDException("\nThere is already a student with this Student ID number");
					                	}
					                }
				                }
					                				                					                				                	
					            catch (DuplicateIDException e) {  //Uses the custom exception for duplicate id class
					                	System.out.println(e.getMessage());
					                						                	
					                }   
					                
					            finally {
					                	
					                }
				                
				                //Creates a new Graduate Student Object with collected input
				                GraduateStudent gradStudent = new GraduateStudent(sID,  myName, myAge, myMajor, myGrades, advisorName, thesisTitle);
				                	students.add(gradStudent); //Adds new object to the Students array
				            }
				               
				               
				               
				               // *********Assign Undergrad Method**********
				            
				            public static void assignUndergrad() {
				            	
				            	System.out.print("Enter student ID in the form of A123: ");
				            	//Scanner object to collect inputs
				                Scanner keyboard = new Scanner(System.in);			                
				                	String sID = keyboard.nextLine();
				                				              				              				                				                				                				          				          				                				                			                
				                //Get UnderGraduate Student Name
				                System.out.print("\nEnter student name: ");
				                	String myName = keyboard.nextLine();
				                				                				                
				                //Get UnderGraduate Student Major
				                System.out.print("\nEnter student major: ");
				                	String  myMajor = keyboard.nextLine();
				                				               				                
				                //Get UnderGraduate Student age
				                System.out.print("\nEnter student age: ");
				                	int  myAge = keyboard.nextInt();
				                 				          				                				                
				                //Get UnderGraduate Student Grade
				                System.out.print("\nEnter Student Grade: ");
				                	ArrayList <Double> myGrades = new ArrayList<>();
				                	double grades =	keyboard.nextDouble();
				                	myGrades.add(grades);
				                	keyboard.nextLine();
				                
				                //Get UnderGraduate Minor				              				             				                
				                System.out.println("\nEnter Student Minor Name: type NONE if no minor: \n");				                
				                	String minor = keyboard.nextLine();
				                
				                		if (minor == "NONE") {  //Condition that initialized to null
				                			minor = null;
				                }
				                				               				                
				                //Get UnderGraduate Student College Year
				                System.out.println("\nEnter Student College Year:  1 for Freshman - 2 for Sophomore - 3 for Junior - 4 for Senior: ");
				                	int yrsOfStudy = keyboard.nextInt();
				                
				                System.out.println();
				            	
				                
				                //Enter a Try/Catch block to catch Duplicate ID
				                try {
					                for (Student student : students) {
					                	if (student.getStudentId().equals(sID)) {   //For loop to loop through the array to find duplicate
						                	throw new DuplicateIDException("\nThere is already a student with this Student ID number");
					                	}
					                }
				                }
					                				                					                					                	
					            catch (DuplicateIDException e) {  //Uses the custom exception for duplicate id class
					                	System.out.println(e.getMessage());					                						                	
					                }   
					                
					            finally {
					                	
					                }
				            	//Create Undergrad student object with collected inputs
				            	UnderGraduate underGrad = new UnderGraduate(sID, myName, myAge, myMajor, myGrades, yrsOfStudy, minor);
				            		students.add(underGrad); //Adds new object to students array				            					            	
				            }
				               
				              
				            
				            
				            
				             //*******WRITE TO A FILE METHOD********  
				            public static void createFile()  {
				            	
				             //Try Catch Block to ensure correct inputs.
                                try {

                                  FileOutputStream myStudentData = new FileOutputStream("StudentSystem.dat");
                                  ObjectOutputStream outputStudentData = new ObjectOutputStream(myStudentData);
                                  
                                  
                             // For Loop to loop through the objects in student array and write to file. 
                                 for (Student student: students)  {                                	 
                                	 outputStudentData.writeObject(student);

                                 
                                  }
                            //Acknowledgement of Success     
                                 System.out.println("Data Written to File Successfully");
                                 
                                 

                                } catch (IOException e) {
                                	System.out.println("An error occurred.");
                                		e.printStackTrace();  // Helps identify where any potential issues have occurred

                                }

                                }
				            
				            
				            
				            
				            
				            
				            
				            //READ FROM A FILE METHOD (LOAD)

                              public static void readFile() throws ClassNotFoundException {

                                try {
                                	Scanner keyboard = new Scanner(System.in);
                                	System.out.println("\nPlease enter the name of the file you would like to load in:");
                                	
                                	String fileSearch = keyboard.nextLine();
                              
                                  FileInputStream studentFile = new FileInputStream(fileSearch);
                                  ObjectInputStream objectInputFile = new ObjectInputStream(studentFile);

                                  for (Student student : students) {
                                	  objectInputFile.readObject(); 
                                	  System.out.println();
                                	  
                                	  
                                  }
                                  System.out.println("Successfully Read the file.");
                                  objectInputFile.close();
                                  
                                  for (Student student : students) {
                                	  System.out.println();
                                	  System.out.println(student.toString());
                                  }
                                  
                                  
                                  
                                 
                                } catch (Exception e) {

                                  System.out.println("An error occurred.");

                                  e.printStackTrace();

                                }

                              }

                              
                              
                                






                               
				            
	//**************************************************************************			            
				            
	// Assignment 3 work  (  Binary Search method,  Load file data,  Sorting Algorithm(Merge)	)		            



		public static int binarySearch(int[] array, int sID) {
			int first = 0;   //First position of array
			int last = array.length - 1; //Last position (remember the minus 1 since index starts at 0
			int position = -1;		
			boolean found = false; //Used to flag the search for value
						
			// statements to identify position
								
			//Use while loop to continue 
			
			while(first <= last) {
				int middle = (first + last)/2;  //Finds the middle position index of current array
				
			
			if (array[middle] == sID) {
				found = true;
				position = middle;
								
			}
			else if (array[middle] > sID) {   // used if the value is in lower half
				last = middle-1; 
							
			}
			else 
				first = middle + 1;
																		
		}
			return position;

		}		
				            
				            
				            
				            
				            
				            
				            
				            
				            
				            
	//***************************************************************************
		
		public static void loadStudentsFromFile(String fileName) throws FileNotFoundException {
			//Create a Local Scanner Object for User input ( Used if need to input a file name)
			Scanner keyboard = new Scanner(System.in);
			
			//System.out.println("Please enter the full file path for the file to upload: ");
			
			//Used as counter to display each line that is Uploading
			int lineNumber = 0;
			
			//"C:\\Users\\jaket\\OneDrive\\Desktop\\students_data.txt"	 For Assignment		
			File fileStudents = new File(fileName);	
			
			//Scanner object that scans the lines in file 
			Scanner scan = new Scanner(fileStudents);
			
			//Continues to read the next line and parse the information into variables
			while(scan.hasNextLine()) {
				lineNumber++; //Line counter to display loading contents
				String studentLine = scan.nextLine();
				
			//Here is to display each object that is being read from the file using counter
				System.out.println("Reading line " + lineNumber + ": " + studentLine);
				String[] studentInfo = studentLine.split(","); //This is used to separate each student into its own array to manipulate
				
				
				//If statement will place each field into a variable to create an object later
				if (studentInfo.length == 5) {
					String studentID = studentInfo[0];
					String name = studentInfo[1];
					int age = Integer.parseInt(studentInfo[2]);
					String major = studentInfo[3];
					
					
				//Creates a Grade GPA Array by splitting each with the ';' Character
				String[] gradeGPA = studentInfo[4].split(";");   
				ArrayList<Double> grades = new ArrayList<>();
				
				
				//Try Catch Block To make sure the formatting for the file is correct
				//Needs Work
				try {	
				
					for (String grade : gradeGPA) {
						grades.add(Double.parseDouble(grade.trim())); //Trim is used just in case there are 'white spaces'							
				}
					
				} catch (NumberFormatException e) {
					
					System.out.println("Error Parsing Grades for student: " + studentID);
						e.printStackTrace();
																									
				}
				
				//Creates a student object for each line in the file 
					Student student = new Student(studentID, name, age, major, grades);
					
				//After Each Student is created,  implement the method the calculate the GPA recursively. 
					student.calculateGPARecursively();
					
					
				//Add the student to the ArrayList when loading file	
					students.add(student);
					
				}else {
					System.out.println("Incorrect Data Formatting" + studentLine); //Used to continue the block if it was formatted incorrectly
					
				}
																			
			}
			
			scan.close();//Closse file
			System.out.println("Student data upload complete!"); //Acknowledgement of Loading
			
		//STILL NEEDS MORE WORK!!	
			

		}

	

			
		
				            
				            
		}		            
				            
		
	//Not using currently	
				            
/*			//Instantiating 2 course objects

Course calculus3 = new Course("MATH3351", "Calculus3", "Meow", 4);

Course pf3 = new Course("COSC2436", "PF3", "Cook", 4);



//Instantiating 2 student objects

Student Amana = new Student("a123", "Amana", 20, "CompSci", 3.5);

Student Jake = new Student("j234", "Jake", "CompSci", 20, 100);



//Add instantiated student objects in student array

students.add(Jake);

students.add(Amana);

//Add instantiated course objects in course array

courses.add(calculus3);

courses.add(pf3);
	            
				            
*/				            
				            
				            	   
				            	
				            		
				            	
				            	   
				            	   
				            	   
				               
	
				            	   
		        
						
		        

		        

		        

		        

		        

		        

		        

	

	

	

	

	

	

		

		

		

		

		

	