package defaultPackage;


//Class to Create Custom Exception that Extends the Exception Class
public class DuplicateIDException extends Exception{

	
	
	//Custom Exception to Display message
	public DuplicateIDException(String message) {
		super(message);
	}
	
}
